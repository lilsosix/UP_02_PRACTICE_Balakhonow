﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FurnitureStoreApp
{
    /// <summary>
    /// Форма авторизации. Проверяет логин/пароль по БД, заполняет CurrentSession.
    /// </summary>
    public partial class LoginForm : Form
    {
        private string connectionString = DatabaseConnection.ConnectionString;

        public LoginForm()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
            txtUsername.MaxLength = 50;
            txtPassword.MaxLength = 50;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль.", "Ошибка авторизации",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ClearFields();
                return;
            }

            string passwordHash = PasswordHelper.HashPassword(password);

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"
                        SELECT u.id, u.full_name, u.login, u.role_id, r.name AS role_name
                        FROM users u
                        LEFT JOIN roles r ON u.role_id = r.id
                        WHERE u.login = @login AND u.password = @password";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", passwordHash);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            CurrentSession.UserId   = Convert.ToInt32(reader["id"]);
                            CurrentSession.FullName = reader["full_name"].ToString();
                            CurrentSession.Login    = reader["login"].ToString();
                            CurrentSession.RoleId   = Convert.ToInt32(reader["role_id"]);
                            CurrentSession.RoleName = reader["role_name"].ToString();
                            reader.Close();
                            OpenRoleMenu();
                        }
                        else
                        {
                            MessageBox.Show("Неверный логин или пароль.", "Ошибка авторизации",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            ClearFields();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ClearFields();
            }
        }

        /// <summary>
        /// Открывает меню соответственно роли: 3-Администратор, 2-Менеджер, 1-Товаровед.
        /// </summary>
        private void OpenRoleMenu()
        {
            switch (CurrentSession.RoleId)
            {
                case 3:
                    new AdminMenu().Show();
                    break;
                case 2:
                    new ManagerMenu().Show();
                    break;
                case 1:
                    new MerchandiserMenuForm().Show();
                    break;
                default:
                    MessageBox.Show("Неизвестная роль пользователя.", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }
            this.Hide();
        }

        private void ClearFields()
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e) { }
    }
}